//
//  Confirmacion.swift
//  Pizza Iphone
//
//  Created by Marta González-Llanos on 1/5/16.
//  Copyright © 2016 Marta González-Llanos. All rights reserved.
//

import UIKit

protocol pedirPizzaDelegate {
    func nuevoPedido()
}

class Confirmacion: UIViewController {
    
    @IBOutlet weak var btnCancelar: UIButton!
    @IBOutlet weak var btnConfirmar: UIButton!
    @IBOutlet weak var textIngredientes: UITextView!
    @IBOutlet weak var btnAceptar: UIButton!
    @IBOutlet weak var labelQueso: UILabel!
    @IBOutlet weak var labelMasa: UILabel!
    @IBOutlet weak var labelTamano: UILabel!
    @IBOutlet weak var btnNuevoPedido: UIButton!
    @IBOutlet weak var labelConfirmar: UILabel!
        
    var delegate: pedirPizzaDelegate? = nil
    var pedirPizza: Pizza?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mostrarPedido()
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
    func mostrarPedido() {
        labelTamano.text = pedirPizza?.tamano
        labelMasa.text = pedirPizza?.claseMasa
        labelQueso.text = pedirPizza?.claseQueso
        var ingredientes: String = ""
        for (_, value) in (pedirPizza?.ingredientes)! {
            ingredientes += "\(value)\n"
        }
        let index1 = ingredientes.substringToIndex(ingredientes.endIndex.predecessor())
        textIngredientes.text = index1
        print(ingredientes)
    }
    
    @IBAction func btnAceptar(sender: AnyObject) {
        print("Enviar a cocina")
        mostrarAlerta("Confirmar", message: "Confirme tenvío a cocina", owner: self)
    }
    
    @IBAction func btnCancelar(sender: AnyObject) {
        print("Editar o cancelar")
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    func mostrarAlerta (title: String, message: String, owner:UIViewController) {

        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertActionStyle.Default, handler:{ (ACTION:UIAlertAction!)in
            self.labelConfirmar.text = "Tu pedido fue enviado a cocina"
            self.btnCancelar.hidden = true
            self.btnAceptar.hidden = true
            self.btnConfirmar.hidden = false
            //print("User click Accept button")
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Cancel, handler:{ (ACTION:UIAlertAction!)in
            //print("User click Cancel button")
        }))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    @IBAction func createNewOrder(sender: AnyObject) {
        if delegate != nil {
            delegate!.nuevoPedido()
            self.navigationController?.popViewControllerAnimated(true)
        }
    }
}