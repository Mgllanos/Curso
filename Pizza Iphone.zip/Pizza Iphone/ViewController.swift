//
//  ViewController.swift
//  Pizza Iphone
//
//  Created by Marta González-Llanos on 28/4/16.
//  Copyright © 2016 Marta González-Llanos. All rights reserved.
//



import UIKit

protocol Delegate {
    func setQuesos (queso:String)
    func setMasa (masa:String)
    func setTamano (tamano:String)
    func setIngredientes (ingredientes:[String:String])
}

class ViewController: UIViewController, quesoDelegate, masaDelegate, pedirPizzaDelegate, tamanoDelegate, ingredientesPizzaDelegate {
    
    
    @IBOutlet weak var btnTamano: UIButton!
    @IBOutlet weak var btnMasa: UIButton!
    @IBOutlet weak var btnQueso: UIButton!
    @IBOutlet weak var btnIngredientes: UIButton!    
   
    var pizzaCliente: Pizza = Pizza()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
      if segue.identifier == "claseMasa" {
            let Masa = segue.destinationViewController as! vistaMasa
            Masa.masaTmp = pizzaCliente
            Masa.delegate = self
            
        }else if segue.identifier == "claseQueso" {
            let verQuesos = segue.destinationViewController as! vistaQuesos
            verQuesos.quesoTmp = pizzaCliente
            verQuesos.delegate = self
            
      }else if segue.identifier == "tamanoPizza" {
        let secondView:VistaTamano = segue.destinationViewController as! VistaTamano
        secondView.tamanoTmp = pizzaCliente
        secondView.delegate = self
      }else if segue.identifier == "Ingredientes" {
        let vistaIngredientes:Ingredientes = segue.destinationViewController as! Ingredientes
        vistaIngredientes.ingredientesTmp = pizzaCliente
        vistaIngredientes.delegate = self
        }
        }

    
    func showAlertMessage (title: String, message: String, owner:UIViewController) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.ActionSheet)
        alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertActionStyle.Default, handler:{ (ACTION :UIAlertAction!)in
        }))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    @IBAction func btnConfirmar (sender: AnyObject) {
        if validarSeleccion(){
            let confirmacion = self.storyboard?.instantiateViewControllerWithIdentifier("Confirmar") as? Confirmacion
            confirmacion!.delegate = self
            confirmacion!.pedirPizza = pizzaCliente
            self.navigationController?.pushViewController(confirmacion!, animated: true)
            
        }else {
            showAlertMessage("Atención", message: "No has seleccionado todas las opciones", owner: self)
        }
    }
    
    func validarSeleccion() -> Bool{
        if (pizzaCliente.tamano != nil && pizzaCliente.claseMasa != nil && pizzaCliente.claseQueso != nil && pizzaCliente.ingredientes.count != 0) {
            return true
        }
        return false
    }
    
    func setTamano(tamano:String) -> () {
        pizzaCliente.tamano = tamano
    }
    
    func setMasa(masa: String) -> () {
        pizzaCliente.claseMasa = masa
    }
    
    func setQuesos(queso: String) -> () {
        pizzaCliente.claseQueso = queso
    }
    
    func setIngredientes(ingredientes:[String:String]) -> () {
        pizzaCliente.ingredientes = ingredientes
    }
    
    func nuevoPedido() {
        pizzaCliente.tamano = nil
        pizzaCliente.claseMasa = nil
        pizzaCliente.claseQueso = nil
        pizzaCliente.ingredientes = [String: String]()
    }
}
