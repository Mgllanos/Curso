//
//  Pizza.swift
//  Pizza Iphone
//
//  Created by Marta González-Llanos on 28/4/16.
//  Copyright © 2016 Marta González-Llanos. All rights reserved.
//

import Foundation

class Pizza: NSObject {
    var tamano: String?
    var claseQueso: String?
    var claseMasa: String?
    var ingredientes = [String: String]()
    
    override init() {
        super.init()
    }
    
    init(tamano: String, claseQueso: String, claseMasa: String) {
        self.tamano = tamano
        self.claseQueso = claseQueso
        self.claseMasa = claseMasa
         }
}
