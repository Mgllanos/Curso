//
//  vistaMasa.swift
//  Pizza Iphone
//
//  Created by Marta González-Llanos on 29/4/16.
//  Copyright © 2016 Marta González-Llanos. All rights reserved.
//

import UIKit
protocol masaDelegate {
    func setMasa(masa:String)
}
class vistaMasa: UIViewController {

    @IBOutlet weak var switchDelgada: UISwitch!
    @IBOutlet weak var switchCrujiente: UISwitch!
    @IBOutlet weak var switchGruesa: UISwitch!
    
    var masaTmp:  Pizza?
    var delegate: masaDelegate? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setMasa()
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
    func setMasa() {
        if let doughOld = masaTmp?.claseMasa {
            switch doughOld {
            case "Delgada":
                switchDelgada.setOn(true, animated: true)
            case "Crujiente":
                switchCrujiente.setOn(true, animated: true)
            case "Gruesa":
                switchGruesa.setOn(true, animated: true)
            default:
                switchDelgada.setOn(false, animated: true)
            }
        }
    }
    
    @IBAction func setDelgada(sender: AnyObject) {
        switchCrujiente.setOn(false, animated: true)
        switchGruesa.setOn(false, animated: true)
        setMasa("Delgada")
    }
    
    @IBAction func setCrujiente(sender: AnyObject) {
        switchDelgada.setOn(false, animated: true)
        switchGruesa.setOn(false, animated: true)
        setMasa("Crujiente")
    }
    
    @IBAction func setGruesa(sender: AnyObject) {
        switchDelgada.setOn(false, animated: true)
        switchCrujiente.setOn(false, animated: true)
        setMasa("Gruesa")
    }
    
    func setMasa (masa:String) {
        if delegate != nil {
            delegate!.setMasa(masa)
        }
    }
}