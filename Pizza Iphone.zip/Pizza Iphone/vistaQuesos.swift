//
//  vistaQuesos.swift
//  Pizza Iphone
//
//  Created by Marta González-Llanos on 2/5/16.
//  Copyright © 2016 Marta González-Llanos. All rights reserved.
//

import UIKit


protocol quesoDelegate {
    func setQuesos(queso:String)
}
class vistaQuesos: UIViewController {

    @IBOutlet weak var switchMozzarella: UISwitch!
    @IBOutlet weak var switchCheddar: UISwitch!
    @IBOutlet weak var switchParmesano: UISwitch!
    @IBOutlet weak var switchNo: UISwitch!
    
    var quesoTmp: Pizza?
    var delegate: quesoDelegate? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setQuesos()
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }*/
    
    func setQuesos() {
        if let cheeseOld = quesoTmp?.claseQueso {
            switch cheeseOld {
            case "Mozzarella":
                switchMozzarella.setOn(true, animated: true)
            case "Cheddar":
                switchCheddar.setOn(true, animated: true)
            case "Parmesano":
                switchParmesano.setOn(true, animated: true)
            case "Sin queso":
                switchNo.setOn(true, animated: true)
            default:
                switchNo.setOn(false, animated: true)
            }
        }
    }
    
    @IBAction func setMozzarella(sender: AnyObject) {
        switchCheddar.setOn(false, animated: true)
        switchParmesano.setOn(false, animated: true)
        switchNo.setOn(false, animated: true)
        setQuesos("Mozzarella");
    }
    
    @IBAction func setCheddar(sender: AnyObject) {
        switchMozzarella.setOn(false, animated: true)
        switchParmesano.setOn(false, animated: true)
        switchNo.setOn(false, animated: true)
        setQuesos("Cheddar");
    }
    
    @IBAction func setParmesano(sender: AnyObject) {
        switchMozzarella.setOn(false, animated: true)
        switchCheddar.setOn(false, animated: true)
        switchNo.setOn(false, animated: true)
        setQuesos("Parmesano");
    }
    
    @IBAction func setNo(sender: AnyObject) {
        switchMozzarella.setOn(false, animated: true)
        switchCheddar.setOn(false, animated: true)
        switchParmesano.setOn(false, animated: true)
        setQuesos("Sin queso");
    }
    func setQuesos (queso:String){
        if delegate != nil {
            delegate!.setQuesos(queso)
}
}
}