//
//  Ingredientes.swift
//  Pizza Iphone
//
//  Created by Marta González-Llanos on 30/4/16.
//  Copyright © 2016 Marta González-Llanos. All rights reserved.
//

import UIKit

protocol ingredientesPizzaDelegate {
    func setPizzaIngredientes(ingredientes:[String:String])
}

class Ingredientes: UIViewController {
    
    @IBOutlet weak var switchJamon: UISwitch!
    @IBOutlet weak var switchPepperoni: UISwitch!
    @IBOutlet weak var switchPavo: UISwitch!
    @IBOutlet weak var switchSalchicha: UISwitch!
    @IBOutlet weak var switchAceitunas: UISwitch!
    @IBOutlet weak var switchCebolla: UISwitch!
    @IBOutlet weak var switchPimiento: UISwitch!
    @IBOutlet weak var switchPina: UISwitch!
    @IBOutlet weak var switchAnchoas: UISwitch!
    @IBOutlet weak var switchAlcaparras: UISwitch!
    
    
    var delegate: ingredientesPizzaDelegate? = nil
    var ingredientesTmp:  Pizza?
    var ingredientes = [String:String] ()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        setIngredientesOn ()
        ingredientes = (ingredientesTmp?.ingredientes)!
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }

     */
    
    func setIngredientesOn() {
        for (_,value) in (ingredientesTmp?.ingredientes)! {
            switch value {
            case "Jamón":
                switchJamon.setOn(true, animated: true)
            case "Pepperoni":
                switchPepperoni.setOn(true, animated: true)
            case "Pavo":
                switchPavo.setOn(true, animated: true)
            case "Salchichas":
                switchSalchicha.setOn(true, animated: true)
            case "Aceitunas":
                switchCebolla.setOn(true, animated: true)
            case "Cebolla":
                switchCebolla.setOn(true, animated: true)
            case "Pimiento":
                switchPimiento.setOn(true, animated: true)
            case "Piña":
                switchPina.setOn(true, animated: true)
            case "Anchoas":
                switchAnchoas.setOn(true, animated: true)
            case "Alcaparras":
                switchAlcaparras.setOn(true, animated: true)
            default:
                switchJamon.setOn(false, animated: true)
            }
            
        }
        
        // Ingresar los que ya tiene al diccionario no borrarlos
    }
    
    func existIngrediente(key: String) -> Bool {
        if  (ingredientes[key] == nil) {
            return true
        }else {
            return false
        }
    }
    
    func availableSpace() -> Bool {
        if ingredientes.count < 5 {
            return true
        }else {
            return false
        }
        
    }
    
    @IBAction func setJamon(sender: AnyObject) {
        let added = switchJamon.on
        if added != true {
            ingredientes["Jamón"] = nil
            setPizzaIngredientes(ingredientes)
        }else {
            if availableSpace() {
                ingredientes["Jamón"] = "Jamón"
            }else {
                switchJamon.setOn(false, animated: true)
            }
            setPizzaIngredientes(ingredientes)
        }
    }
    
    @IBAction func setPepperoni(sender: AnyObject) {
        let added = switchPepperoni.on
        if added != true {
            ingredientes["Pepperoni"] = nil
            setPizzaIngredientes(ingredientes)        }else {
            if availableSpace() {
                ingredientes["Pepperoni"] = "Pepperoni"
            }else {
                switchPepperoni.setOn(false, animated: true)
            }
            setPizzaIngredientes(ingredientes)
        }
    }
    
    @IBAction func setPavo(sender: AnyObject) {
        let added = switchPavo.on
        if added != true {
            ingredientes["Pavo"] = nil
            setPizzaIngredientes(ingredientes)        }else {
            if availableSpace() {
                ingredientes["Pavo"] = "Pavo"
            }else {
                switchPavo.setOn(false, animated: true)
            }
            setPizzaIngredientes(ingredientes)
        }
    }
    
    @IBAction func setSalchicha(sender: AnyObject) {
        let added = switchSalchicha.on
        if added != true {
            ingredientes["Salchicha"] = nil
            setPizzaIngredientes(ingredientes)
        }else {
            if availableSpace() {
                ingredientes["Salchciha"] = "Salchicha"
            }else {
                switchSalchicha.setOn(false, animated: true)
            }
            setPizzaIngredientes(ingredientes)        }
    }
    
    @IBAction func setAceituna(sender: AnyObject) {
        let added = switchAceitunas.on
        if added != true {
            ingredientes["Aceitunas"] = nil
           setPizzaIngredientes(ingredientes)
        }else {
            if availableSpace() {
                ingredientes["Aceitunas"] = "Aceitunas"
            }else {
                switchAceitunas.setOn(false, animated: true)
            }
           setPizzaIngredientes(ingredientes)
        }
    }
    
    @IBAction func setCebolla(sender: AnyObject) {
        let added = switchCebolla.on
        if added != true {
            ingredientes["Cebolla"] = nil
           setPizzaIngredientes(ingredientes)
        }else {
            if availableSpace() {
                ingredientes["Cebolla"] = "Cebolla"
            }else {
                switchCebolla.setOn(false, animated: true)
            }
            setPizzaIngredientes(ingredientes)
        }
    }
    
    @IBAction func setPimiento(sender: AnyObject) {
        let added = switchPimiento.on
        if added != true {
            ingredientes["Pimiento"] = nil
           setPizzaIngredientes(ingredientes)
        }else {
            if availableSpace() {
                ingredientes["Pimiento"] = "Pimiento"
            }else {
                switchPimiento.setOn(false, animated: true)
            }
        setPizzaIngredientes(ingredientes)}
    }
    
    @IBAction func setPina(sender: AnyObject) {
        let added = switchPina.on
        if added != true {
            ingredientes["Piña"] = nil
            setPizzaIngredientes(ingredientes)
        }else {
            if availableSpace() {
                ingredientes["Piña"] = "Piña"
            }else {
                switchPina.setOn(false, animated: true)
            }
            setPizzaIngredientes(ingredientes)
        }
    }
    
    @IBAction func setAnchoa(sender: AnyObject) {
        let added = switchAnchoas.on
        if added != true {
            ingredientes["Anchoas"] = nil
           setPizzaIngredientes(ingredientes)
        }else {
            if availableSpace() {
                ingredientes["Anchoas"] = "Anchoas"
            }else {
                switchAnchoas.setOn(false, animated: true)
            }
            setPizzaIngredientes(ingredientes)
        }
    }
    @IBAction func setAlcaparra(sender: AnyObject) {
        let added = switchAlcaparras.on
        if added != true {
            ingredientes["Alcaparras"] = nil
            setPizzaIngredientes(ingredientes)
        }else {
            if availableSpace() {
                ingredientes["Alcaparras"] = "Alcaparras"
            }else {
                switchAlcaparras.setOn(false, animated: true)
            }
            setPizzaIngredientes(ingredientes)
        }
    }
    
    func setPizzaIngredientes (ingredientes:[String:String]){
    
    if delegate != nil {
            delegate!.setPizzaIngredientes(ingredientes)
        }
}
}