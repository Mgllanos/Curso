//
//  VistaTamano.swift
//  Pizza Iphone
//
//  Created by Marta González-Llanos on 28/4/16.
//  Copyright © 2016 Marta González-Llanos. All rights reserved.
//

import UIKit

protocol tamanoDelegate {
    func setTamano(tamano:String)
}
class VistaTamano: UIViewController {

    @IBOutlet weak var switchChica: UISwitch!
    @IBOutlet weak var switchMediana: UISwitch!
    @IBOutlet weak var switchGrande: UISwitch!
    
    var tamanoTmp:  Pizza?
    var delegate: tamanoDelegate? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        setTamano()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
    func setTamano() {
        if let sizeOld = tamanoTmp?.tamano {
            switch sizeOld {
            case "Chica":
                switchChica.setOn(true, animated: true)
            case "Mediana":
                switchMediana.setOn(true, animated: true)
            case "Grande":
                switchGrande.setOn(true, animated: true)
            default:
                switchChica.setOn(false, animated: true)
            }
        }
    }
    
    @IBAction func switchChica(sender: AnyObject) {
        switchMediana.setOn(false, animated: true)
        switchGrande .setOn(false, animated: true)
        setTamano("Chica")
    }
    @IBAction func switchMediana(sender: AnyObject) {
        switchChica.setOn(false, animated: true)
        switchGrande.setOn(false, animated: true)
        setTamano("Mediana")
    }
    
    @IBAction func switchGrande(sender: AnyObject) {
        switchChica.setOn(false, animated: true)
        switchMediana.setOn(false, animated: true)
        setTamano("Grande")
    }
    
    func setTamano (tamano:String){
        if delegate != nil {
            delegate!.setTamano(tamano)
    }
}
}