//
//  ViewController.swift
//  Pizza
//
//  Created by Marta González-Llanos on 25/5/16.
//  Copyright © 2016 Marta González-Llanos. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated
    }
 
    func showAlertMessage (title: String, message: String, owner:UIViewController) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.ActionSheet)
        alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertActionStyle.Default, handler:{ (ACTION :UIAlertAction!)in
        }))
        self.presentViewController(alert, animated: true, completion: nil)
    }

    @IBAction func btnPizza(sender: AnyObject) {
        if validarSelectores (){
            let viewConfirmOrder = self.storyboard?.instantiateViewControllerWithIdentifier("vistaConfirmacion") as? vistaConfirmacion
            self.navigationController?.pushViewController(viewConfirmOrder!, animated: true)
            
        }else {
            showAlertMessage("Atención", message: "No has seleccionados todas las opciones", owner: self)
        }
   }
    
    func validarSelectores() -> Bool{
        if (Pizza.sharedPizza.tamaño != nil && Pizza.sharedPizza.masa != nil && Pizza.sharedPizza.queso != nil && Pizza.sharedPizza.cIngredientes != nil) {
            return true
        }
        return false
    }
    }
