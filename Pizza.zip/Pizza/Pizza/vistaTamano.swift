//
//  vistaTamano.swift
//  Pizza
//
//  Created by Marta González-Llanos on 25/5/16.
//  Copyright © 2016 Marta González-Llanos. All rights reserved.
//

import UIKit

class vistaTamano: UIViewController {

    
    @IBOutlet weak var swChica: UISwitch!
    @IBOutlet weak var swMediana: UISwitch!
    @IBOutlet weak var swGrande: UISwitch!
    @IBOutlet weak var labelTamano: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
 
 
    var tamano:(String) = ("")
    
    
    @IBAction func swChica(sender: AnyObject) {
    
            labelTamano.text = ("Chica")
            swGrande.setOn(false, animated: true)
            swMediana.setOn(false, animated: true)
            tamano = ("Chica")
        }
    
    @IBAction func swMediana(sender: AnyObject) {
    
                labelTamano.text = ("Mediana")
                swGrande.setOn(false, animated: true)
                swChica.setOn(false, animated: true)
                tamano = ("Mediana")
        }
    
    
    @IBAction func swGrande(sender: AnyObject) {
        
                labelTamano.text = ("Grande")
                swChica.setOn(false, animated: true)
                swMediana.setOn(false, animated: true)
                tamano = ("Grande")
 
    }

    @IBAction func boton(sender: AnyObject) {
        Pizza.sharedPizza.tamaño = tamano
    }
}