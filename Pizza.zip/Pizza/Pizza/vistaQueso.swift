//
//  vistaQueso.swift
//  Pizza
//
//  Created by Marta González-Llanos on 25/5/16.
//  Copyright © 2016 Marta González-Llanos. All rights reserved.
//

import UIKit

class vistaQueso: UIViewController {

    @IBOutlet weak var swMozzarella: UISwitch!
    @IBOutlet weak var swCheddar: UISwitch!
    @IBOutlet weak var swParmesano: UISwitch!
    @IBOutlet weak var swSinQueso: UISwitch!
    @IBOutlet weak var labelQueso: UILabel!

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    var queso:(String)? = ("")
    
    @IBAction func swMozarella(sender: AnyObject) {
        labelQueso.text = ("Mozzarella")
        swCheddar.setOn(false, animated: true)
        swParmesano.setOn(false, animated: true)
        swSinQueso.setOn(false, animated: true)
        queso = ("Mozzarella")
       
    }
    
    @IBAction func swCheddar(sender: AnyObject) {
        labelQueso.text = ("Cheddar")
        swMozzarella.setOn(false, animated: true)
        swParmesano.setOn(false, animated: true)
        swSinQueso.setOn(false, animated: true)
        queso = ("Cheddar")
        
    }
    
    @IBAction func swParmesano(sender: AnyObject) {
        labelQueso.text = ("Parmesano")
        swCheddar.setOn(false, animated: true)
        swMozzarella.setOn(false, animated: true)
        swSinQueso.setOn(false, animated: true)
        queso = ("Parmesano")
        
    }
    @IBAction func swSinQueso(sender: AnyObject) {
        labelQueso.text = ("Sin Queso")
        swCheddar.setOn(false, animated: true)
        swParmesano.setOn(false, animated: true)
        swMozzarella.setOn(false, animated: true)
        queso = ("Sin Queso")
     
    }
    
    @IBAction func boton(sender: AnyObject) {
               Pizza.sharedPizza.queso = queso
    }
}
