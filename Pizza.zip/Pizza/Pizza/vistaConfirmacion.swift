//
//  vistaConfirmacion.swift
//  Pizza
//
//  Created by Marta González-Llanos on 26/5/16.
//  Copyright © 2016 Marta González-Llanos. All rights reserved.
//

import UIKit

class vistaConfirmacion: UIViewController {

    @IBOutlet weak var labelTamano: UILabel!
    @IBOutlet weak var labelMasa: UILabel!
    @IBOutlet weak var labelQueso: UILabel!
    @IBOutlet weak var textoIngredientes: UITextView!
    @IBOutlet weak var labelMensaje: UILabel!
    @IBOutlet weak var btnConfirmar: UIButton!
    @IBOutlet weak var btnNuevo: UIButton!
    @IBOutlet weak var btnCancelar: UIButton!
    @IBOutlet weak var btnActualizar: UIButton!
  
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated
    }

 
    
    func showAlertMessage (title: String, message: String, owner:UIViewController) {
        
    let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.Alert)
    alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertActionStyle.Default, handler:{ (ACTION:UIAlertAction!)in
    self.labelMensaje.text = "Tu pedido fue enviado a cocina"
    self.btnCancelar.hidden = true
    self.btnConfirmar.hidden = true
    self.btnActualizar.hidden = true
    self.btnNuevo.hidden = false
    }))
    
    alert.addAction(UIAlertAction(title: "Cancelar", style: UIAlertActionStyle.Cancel, handler:{ (ACTION:UIAlertAction!)in
    //print("User click Cancel button")
    }))
    self.presentViewController(alert, animated: true, completion: nil)
    }

    @IBAction func btnActualizar(sender: AnyObject) {
        var countOfThem = 0;
 
        if Pizza.sharedPizza.masa != nil {
            labelMasa.text = Pizza.sharedPizza.masa;
            countOfThem += 1
        }
 
        if Pizza.sharedPizza.queso != nil {
            labelQueso.text = Pizza.sharedPizza.queso;
            countOfThem += 1
        }
 
        if Pizza.sharedPizza.tamaño != nil {
            labelTamano.text = Pizza.sharedPizza.tamaño;
            countOfThem += 1
        }
        if Pizza.sharedPizza.cIngredientes != nil {
            countOfThem += 1
            var textToSet: String = " "
            for value in Pizza.sharedPizza.cIngredientes!{
                textToSet += String(value) + ", "
                
            }
            textoIngredientes.text = textToSet
        }
        
    }


    @IBAction func btnConfirmar(sender: AnyObject) {
        print("Enviar a cocina")
        showAlertMessage("Confirmar", message: "Confirma envío a cocina", owner: self)
    }
    

    @IBAction func btnNuevo(sender: AnyObject) {
        Pizza.sharedPizza.tamaño = nil
        Pizza.sharedPizza.masa = nil
        Pizza.sharedPizza.queso = nil
        Pizza.sharedPizza.ingredientes = nil
 }
    
}
