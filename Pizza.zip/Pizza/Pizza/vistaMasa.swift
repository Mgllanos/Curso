//
//  vistaMasa.swift
//  Pizza
//
//  Created by Marta González-Llanos on 25/5/16.
//  Copyright © 2016 Marta González-Llanos. All rights reserved.
//

import UIKit

class vistaMasa: UIViewController {


    @IBOutlet weak var swFina: UISwitch!
    @IBOutlet weak var swCrujiente: UISwitch!
    @IBOutlet weak var swGruesa: UISwitch!
    @IBOutlet weak var labelMasa: UILabel!
  


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    var masa:(String)? = ("")
    
    @IBAction func swFina(sender: AnyObject) {
        
        labelMasa.text = ("Fina")
        swGruesa.setOn(false, animated: true)
        swCrujiente.setOn(false, animated: true)
        masa = ("Fina")
    }
    
    @IBAction func swCrujiente(sender: AnyObject) {
        labelMasa.text = ("Crujiente")
        swGruesa.setOn(false, animated: true)
        swFina.setOn(false, animated: true)
        masa = ("Crujiente")
    }
    
    @IBAction func swGruesa(sender: AnyObject) {
        labelMasa.text = ("Gruesa")
        swFina.setOn(false, animated: true)
        swCrujiente.setOn(false, animated: true)
        masa = ("Gruesa")
    }
 
    
    @IBAction func boton(sender: AnyObject) {
 
        Pizza.sharedPizza.masa = masa
}

}