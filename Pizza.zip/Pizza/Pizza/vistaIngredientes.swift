//
//  vistaIngredientes.swift
//  Pizza
//
//  Created by Marta González-Llanos on 25/5/16.
//  Copyright © 2016 Marta González-Llanos. All rights reserved.
//

import UIKit

class vistaIngredientes: UIViewController {

    @IBOutlet weak var swJamon: UISwitch!
    @IBOutlet weak var swPepperoni: UISwitch!
    @IBOutlet weak var swPavo: UISwitch!
    @IBOutlet weak var swSalchicha: UISwitch!
    @IBOutlet weak var swAceitunas: UISwitch!
    @IBOutlet weak var swCebolla: UISwitch!
    @IBOutlet weak var swPimiento: UISwitch!
    @IBOutlet weak var swPiña: UISwitch!
    @IBOutlet weak var swAnchoas: UISwitch!
    @IBOutlet weak var swPollo: UISwitch!
    @IBOutlet weak var labelIngredientes: UILabel!
    
    
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
  
    var ingredientes:[String] = []
    
    var agregados:[String]? = [String] ();
 

 func espacio () -> Bool {
    
        if ingredientes.count < 5 {
           return true
        } else {
           return false
        }
    }

    
    @IBAction func setJamon(sender: AnyObject) {

            let added = swJamon.on
            if added != true {
            ingredientes.append("Jamón")
            }else {
            if espacio() {
            ingredientes.append("Jamón")
            } else {
            swJamon.setOn(false, animated: true)
        }
    }
    }
    
    @IBAction func setPepperoni(sender: AnyObject) {
        let added = swPepperoni.on
        if added != true {
            ingredientes.append("Pepperoni")
         } else {
            if espacio () {
            ingredientes.append("Pepperoni")
            } else {
            swPepperoni.setOn(false, animated: true)
        }
    }
    }
    
    @IBAction func setPavo(sender: AnyObject) {

        let added = swPavo.on
        if added != true {
           ingredientes.append("Pavo")
        } else {
         if espacio () {
            ingredientes.append("Pavo")
         } else {
            swPavo.setOn(false, animated: true)
        }
    }
    }
    
    @IBAction func setSalchicha(sender: AnyObject) {
        let added = swSalchicha.on
        if added != true {
            ingredientes.append("Salchicha")
        } else {
        if espacio () {
            ingredientes.append("Salchicha")
        } else {
            swSalchicha.setOn(false, animated: true)
        }
    }
    }
    
    @IBAction func setAceitunas(sender: AnyObject) {
        let added = swAceitunas.on
        if added != true {
            ingredientes.append("Aceitunas")
        } else {
        if espacio() {
            ingredientes.append("Aceitunas")
        } else {
           swAceitunas.setOn(false, animated: true)
        }
    }
    }
    
    @IBAction func setCebolla(sender: AnyObject) {
        let added = swCebolla.on
        if added != true {
            ingredientes.append("Cebolla")
        } else {
        if espacio() {
            ingredientes.append("Cebolla")        } else {
           swCebolla.setOn(false, animated: true)
            }
        }
    }
    
    @IBAction func setPimiento(sender: AnyObject) {
        let added = swPimiento.on
        if added != true {
            ingredientes.append("Pimiento")
        } else {
        if espacio() {
            ingredientes.append("Pimiento")
        } else {
            swPimiento.setOn(false, animated: true)
        }
    }
}
    
    @IBAction func setPiña(sender: AnyObject) {
        let added = swPiña.on
        if added != true {
            ingredientes.append("Piña")
        } else {
        if espacio () {
            ingredientes.append("Piña")
        } else {
            swPiña.setOn(false, animated: true)
        }
    }
    }
    
    @IBAction func setAnchoas(sender: AnyObject) {
        let added = swAnchoas.on
        if added != true {
            ingredientes.append("Anchoas")
        } else {
        if espacio () {
           ingredientes.append("Anchoas")
        } else {
            swAnchoas.setOn(false, animated: true)
        }
    }
    }
    
    @IBAction func setPollo(sender: AnyObject) {
        let added = swPollo.on
        if added != true {
            ingredientes.append("Pollo")
        } else {
        if espacio () {
            ingredientes.append("Pollo")
        } else {
            swPollo.setOn(false, animated: true)
        }
    }
    }
    

    
    @IBAction func boton(sender: AnyObject) {
        
        var agregados:[String]? = [String] ();
        
        for  ( ingrediente ) in ingredientes {
            
                agregados?.append(ingrediente)
                
            }
        
            print (agregados!)
        
            var textToSet: String = " "
            
            for value in agregados!{
                
                textToSet += String(value) + ", "
            }
            
            labelIngredientes.text = textToSet


        if textToSet != nil! {
            
            Pizza.sharedPizza.cIngredientes = agregados
            
            print("Ingredientes: ")
            
            Pizza.sharedPizza.ingredientesToString()
            
        }
    }

}



