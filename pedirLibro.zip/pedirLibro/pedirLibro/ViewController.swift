//
//  ViewController.swift
//  pedirLibro
//
//  Created by Marta González-Llanos on 15/6/16.
//  Copyright © 2016 Marta González-Llanos. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var textISBN: UITextField!
    @IBOutlet weak var btnLimpiar: UIButton!
    @IBOutlet weak var spinner: UIActivityIndicatorView!
    @IBOutlet weak var textResultado: UITextView!

    
    
    let baseURL = NSURL(string: "https://openlibrary.org/api/books?jscmd=data&format=json&bibkeys=ISBN:")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        textISBN.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // Ocultar teclado

    @IBAction func textFieldDoneEditing (sender: UITextField) {
        sender.resignFirstResponder()
    }
    
    //Ocultar teclado al tocar en pantalla
    
    @IBAction func backgroundTap ( sender: UIControl) {
        textISBN.resignFirstResponder()
}
    
    //Acciones
    
    @IBAction func captura(sender: AnyObject) {
        if (textISBN.text?.characters.count > 0) {
            self.spinner.startAnimating()
            if let isbn = textISBN.text {
                let url = NSURL(string: "https://openlibrary.org/api/books?jscmd=data&format=json&bibkeys=ISBN:\(isbn)")
                print(url!)
                let sesion = NSURLSession.sharedSession()
                
                let dt = sesion.dataTaskWithURL(url!) {
                    (let datos, let resp, let error) in
                    if let httpResponse = resp as? NSHTTPURLResponse {
                        switch (httpResponse.statusCode) {
                        case 200:
                            let texto = NSString(data: datos!, encoding: NSUTF8StringEncoding)
                            print(texto!)
                            var titulo = ""
                            var autores = ""
                            do {
                                let json = try NSJSONSerialization.JSONObjectWithData(datos!, options: NSJSONReadingOptions.MutableContainers)
                                
                                let dico1 = json as! NSDictionary
                                if let dico2 = dico1["ISBN:\(isbn)"] as? NSDictionary {
                                    let dico3 = dico2["authors"] as? [NSDictionary]
                                    titulo = "\(dico2["title"] as! NSString as String)"
    
                                    if let dicAutores = dico3 {
                                        for autor in dicAutores {
                                            autores += "\(autor["name"] as! NSString as String) "
                                        }
                                    }
                                } else {
                                    titulo = "ISBN no válido"
                                }
                            } catch _ {
                                print("Error")
                            }
                            dispatch_async(dispatch_get_main_queue()) {
                                self.spinner.stopAnimating()
                                //self.textViewResultado?.text = texto! as String
                                self.textResultado!.text = "Autor: \(autores) \n Título: \(titulo)"
                            }
                        default:
                            print("No se puede realizar la operación")
                            
                        }
                    } else {
                        dispatch_async(dispatch_get_main_queue()) {
                            self.spinner.stopAnimating()
                            let alertController = UIAlertController(title: "Error", message:
                                "¡Revisa tu conexión a Internet!", preferredStyle: UIAlertControllerStyle.Alert)
                            alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default,handler: nil))
                            
                            self.presentViewController(alertController, animated: true, completion: nil)
                        }
                        
                    }
                    
                }
                dt.resume()
                
            }
        }
    }
     @IBAction func btnLimpiar(sender: AnyObject) {

        
        self.textResultado.text = ""
        textISBN.text  = ""
}
//ISBN: 9788437604947
}