//
//  Pizza.swift
//  pizzaWatch
//
//  Created by Marta González-Llanos on 9/6/16.
//  Copyright © 2016 Marta González-Llanos. All rights reserved.
//


import Foundation


class Pizza: NSObject {

    var tamano: String?
    var claseMasa: String?
    var claseQueso: String?
    var ingredientes = [String: String]()
    var delegate:AnyObject? = nil
    
    override init() {
        super.init()
    }
    
    init(tamano: String, claseMasa: String, claseQueso: String) {
        self.tamano   = tamano
        self.claseMasa = claseMasa
        self.claseQueso = claseQueso
    }

}
