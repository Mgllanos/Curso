//
//  Masa.swift
//  pizzaWatch
//
//  Created by Marta González-Llanos on 9/6/16.
//  Copyright © 2016 Marta González-Llanos. All rights reserved.
//

import WatchKit
import Foundation

protocol masaPizzaDelegate {
    func setPizzaDMasa(masa:String)
}

class Masa: WKInterfaceController {

    @IBOutlet var swFina: WKInterfaceSwitch!
    @IBOutlet var swCrujiente: WKInterfaceSwitch!
    @IBOutlet var swGruesa: WKInterfaceSwitch!
    
    var delegate: masaPizzaDelegate? = nil
    var pizzaMasaTmp:  Pizza?

    
    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
        
        // Configure interface objects here.
        
        let myContext = context as! Pizza
        delegate = myContext.delegate as? masaPizzaDelegate
        pizzaMasaTmp = myContext
        setMasa()

    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    func setMasa() {
        if let doughOld = pizzaMasaTmp?.claseMasa {
            switch doughOld {
            case "Fina":
                swFina.setOn(true)
            case "Crujiente":
                swCrujiente.setOn(true)
            case "Gruesa":
                swGruesa.setOn(true)
            default:
                swFina.setOn(false)
            }
        }
    }
    


    @IBAction func swFina(value: Bool) {
        swCrujiente.setOn(false)
        swGruesa.setOn(false)
        setPizzaMasa("Fina")
    }
    
    @IBAction func swCrujiente(value: Bool) {
        swFina.setOn(false)
        swGruesa.setOn(false)
        setPizzaMasa("Crujiente")
    }
    
    @IBAction func swGruesa(value: Bool) {
        swFina.setOn(false)
        swCrujiente.setOn(false)
        setPizzaMasa("Gruesa")
    }
    
    func setPizzaMasa(masa: String) {
        //Stept: 3
        if delegate != nil {
            delegate!.setPizzaDMasa(masa)
            //            self.navigationController?.popViewControllerAnimated(true)
        }
    }

}