//
//  InterfaceController.swift
//  pizzaWatch WatchKit Extension
//
//  Created by Marta González-Llanos on 9/6/16.
//  Copyright © 2016 Marta González-Llanos. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController, tamanoPizzaDelegate, quesoPizzaDelegate, masaPizzaDelegate, ingredientesPizzaDelegate, orderPizzaDelegate {

    var customPizza: Pizza = Pizza()
    
    
    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
        
        // Configure interface objects here.
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
 
    @IBAction func btnTamano() {
        customPizza.delegate = self
        pushControllerWithName("vistaTamano", context: customPizza)
    }
    
    @IBAction func btnMasa() {
         customPizza.delegate = self
        pushControllerWithName("vistaMasa", context: customPizza)
    }
    
    @IBAction func btnQueso() {

        customPizza.delegate = self
        pushControllerWithName("vistaQuesos", context: customPizza)
    }
    
    @IBAction func btnIngredientes() {
        customPizza.delegate = self
        pushControllerWithName("vistaIngredientes", context: customPizza)
    }
    
    @IBAction func btnPedir() {
         if validateSelectionSteps(){
            customPizza.delegate = self
            pushControllerWithName("Confirmacion", context: customPizza)
        }else {
            showAlertMessage("No has seleccionado todas las opciones");
        }
    }

    func setPizzaTamano(tamano: String) {
        customPizza.tamano = tamano
    }
    
    func setPizzaDMasa(masa: String) {
        customPizza.claseMasa = masa
    }
    
    func setPizzaIngredientes(ingredientes: [String : String]) {
        
    customPizza.ingredientes = ingredientes
    }
    

    func setPizzaQueso(queso: String) {
        customPizza.claseQueso = queso
    }
    

    func newOrder() {
        customPizza.tamano = nil
        customPizza.claseMasa = nil
        customPizza.claseQueso = nil
        customPizza.ingredientes = [String: String]()
    }
    
    func validateSelectionSteps() -> Bool{
        if (customPizza.tamano != nil && customPizza.claseMasa != nil && customPizza.claseQueso != nil && customPizza.ingredientes.count != 0) {
            return true
        }
        return false
    }
    
    func showAlertMessage(message: String){
        let action1 = WKAlertAction(title: "Aceptar", style: .Default, handler:{})
        let action3 = WKAlertAction(title: "X", style: .Cancel) {}
        self.presentAlertControllerWithTitle("", message: message, preferredStyle: .ActionSheet, actions: [action1, action3])
    }
    
}
