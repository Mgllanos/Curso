//
//  confirmacion.swift
//  pizzaWatch
//
//  Created by Marta González-Llanos on 9/6/16.
//  Copyright © 2016 Marta González-Llanos. All rights reserved.
//

import WatchKit
import Foundation

protocol orderPizzaDelegate {
    func newOrder()
}

class confirmacion: WKInterfaceController {

    @IBOutlet var lblTamano: WKInterfaceLabel!
    @IBOutlet var lblMasa: WKInterfaceLabel!
    @IBOutlet var lblQueso: WKInterfaceLabel!
    @IBOutlet var lblIngredientes: WKInterfaceLabel!
    @IBOutlet var botonAceptar: WKInterfaceButton!
 
    @IBOutlet var botonNuevaPizza: WKInterfaceButton!



  
    var delegate: orderPizzaDelegate? = nil
    var orderPizza: Pizza?

    
    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
        
        // Configure interface objects here.
        let myContext = context as! Pizza
        delegate = myContext.delegate as?orderPizzaDelegate
        orderPizza = myContext
        showOrder()

    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    

        func showOrder() {
            lblTamano.setText(orderPizza?.tamano)
            lblMasa.setText(orderPizza?.claseMasa)
            lblQueso.setText(orderPizza?.claseQueso)
            var ingredientes: String = ""
            for (_, value) in (orderPizza?.ingredientes)! {
                ingredientes += " \(value) "
            }
            lblIngredientes.setText(ingredientes)
        }
        
    @IBAction func btnAceptar() {
  self.botonNuevaPizza.setHidden(false)
    self.botonAceptar.setHidden(true)
    showAlertMessage ("Tu orden fue enviada a cocina")
    }

        
    @IBAction func botonNuevoPedido() {
        if delegate != nil {
        delegate!.newOrder()
        self.pushControllerWithName("Main", context: "")
            }
        }
        
        func showAlertMessage(message: String){
            let action1 = WKAlertAction(title: "Aceptar", style: .Default, handler:{})
            let action3 = WKAlertAction(title: "X", style: .Cancel) {}
            self.presentAlertControllerWithTitle("", message: message, preferredStyle: .ActionSheet, actions: [action1, action3])
        }
        
    }
