//
//  tamano.swift
//  pizzaWatch
//
//  Created by Marta González-Llanos on 9/6/16.
//  Copyright © 2016 Marta González-Llanos. All rights reserved.
//

import WatchKit
import Foundation

protocol tamanoPizzaDelegate {
    func setPizzaTamano(size:String)
}

class tamano: WKInterfaceController {

    @IBOutlet var swChica: WKInterfaceSwitch!
    @IBOutlet var swMediana: WKInterfaceSwitch!
    @IBOutlet var swGrande: WKInterfaceSwitch!
 
    var delegate: tamanoPizzaDelegate? = nil
    var pizzaTamanoTmp:  Pizza?

    
    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
        
        // Configure interface objects here.
        
        let myContext = context as! Pizza
        delegate = myContext.delegate as? tamanoPizzaDelegate
        pizzaTamanoTmp = myContext
        setTamano()

    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    func setTamano() {
        if let sizeOld = pizzaTamanoTmp?.tamano {
            switch sizeOld {
            case "Chica":
                swChica.setOn(true)
            case "Mediana":
                swMediana.setOn(true)
            case "Grande":
                swGrande.setOn(true)
            default:
                swChica.setOn(false)
            }
        }
        
    }
    
    @IBAction func swMediana(value: Bool) {
        swChica.setOn(false)
        swGrande.setOn(false)
        setPizzaTamano("Mediana")
        
    }
    
    @IBAction func swChica(value: Bool) {
        swMediana.setOn(false)
        swGrande.setOn(false)
        setPizzaTamano("Chica")
        
  }
    
    @IBAction func swGrande(value: Bool) {
        swChica.setOn(false)
        swMediana.setOn(false)
        setPizzaTamano("Grande")
    }

        func setPizzaTamano(tamano: String) {
            //Stept: 3
            if delegate != nil {
                delegate!.setPizzaTamano(tamano)
                //            self.navigationController?.popViewControllerAnimated(true)
            }
        }

}