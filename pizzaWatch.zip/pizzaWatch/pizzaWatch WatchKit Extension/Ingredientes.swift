//
//  Ingredientes.swift
//  pizzaWatch
//
//  Created by Marta González-Llanos on 9/6/16.
//  Copyright © 2016 Marta González-Llanos. All rights reserved.
//

import WatchKit
import Foundation

protocol ingredientesPizzaDelegate {
    func setPizzaIngredientes(ingredientes:[String:String])
}
class Ingredientes: WKInterfaceController {

    @IBOutlet var swJamon: WKInterfaceSwitch!
    @IBOutlet var swPepperoni: WKInterfaceSwitch!
    @IBOutlet var swPavo: WKInterfaceSwitch!
    @IBOutlet var swSalchicha: WKInterfaceSwitch!
    @IBOutlet var swAceituna: WKInterfaceSwitch!
    @IBOutlet var swCebolla: WKInterfaceSwitch!
    @IBOutlet var swPimiento: WKInterfaceSwitch!
    @IBOutlet var swPina: WKInterfaceSwitch!
    @IBOutlet var swAnchoa: WKInterfaceSwitch!
    @IBOutlet var swAlcaparras: WKInterfaceSwitch!
    
    var delegate: ingredientesPizzaDelegate? = nil
    var ingredientes = [String: String]()
    var pizzaIngredientesTmp:  Pizza?
    
    var swJamonStatus: Bool = false
    var swPepperoniStatus: Bool = false
    var swPavoStatus: Bool = false
    var swSalchichaStatus: Bool = false
    var swAceitunaStatus: Bool = false
    var swCebollaStatus: Bool = false
    var swPimientoStatus: Bool = false
    var swPinaStatus: Bool = false
    var swAnchoaStatus: Bool = false
    var swAlcaparraStatus : Bool = false
    
    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
        
        // Configure interface objects here.
        let myContext = context as! Pizza
        delegate = myContext.delegate as? ingredientesPizzaDelegate
        pizzaIngredientesTmp = myContext
        ingredientes = (pizzaIngredientesTmp?.ingredientes)!
        setIngredientesOn()

    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    func setIngredientesOn() {
        for (_, value) in (ingredientes) {
            switch value {
            case "Jamón":
                swJamon.setOn(true)
                swJamonStatus = true
            case "Pepperoni":
                swPepperoni.setOn(true)
                swPepperoniStatus = true
            case "Pavo":
                swPavo.setOn(true)
                swPavoStatus = true
            case "Salchicha":
                swSalchicha.setOn(true)
                swSalchichaStatus = true
            case "Aceituna":
                swAceituna.setOn(true)
                swAceitunaStatus = true
            case "Cebolla":
                swCebolla.setOn(true)
                swCebollaStatus = true
            case "Pimiento":
                swPimiento.setOn(true)
                swPimientoStatus = true
            case "Piña":
                swPina.setOn(true)
                swPinaStatus = true
            case "Anchoa":
                swAnchoa.setOn(true)
                swAnchoaStatus = true
            case "Alcaparras":
                swAlcaparras.setOn(true)
                swAlcaparraStatus = true

            default:
                swJamon.setOn(false)
            }
        }
    }
    
    func existIngredient(key: String) -> Bool {
        if  (ingredientes[key] == nil) {
            return true
        }else {
            return false
        }
    }
    
    func availableSpace() -> Bool {
        if ingredientes.count < 5 {
            return true
        }else {
            return false
        }
    }
    
    

    @IBAction func swJamon(value: Bool) {
        if swJamonStatus == true {
            ingredientes["Jamón"] = nil
            setPizzaIngredientes(ingredientes)
        }else {
            if availableSpace() {
                ingredientes["Jamón"] = "Jamón"
            }else {
                swJamon.setOn(false)
                swJamonStatus = false
                ingredientes["Jamón"] = nil
            }
            setPizzaIngredientes(ingredientes)
        }
   }
    
    @IBAction func swPepperoni(value: Bool) {
        if swPepperoniStatus == true {
            ingredientes["Pepperoni"] = nil
            setPizzaIngredientes(ingredientes)
        }else {
            if availableSpace() {
                ingredientes["Pepperoni"] = "Pepperoni"
            }else {
                swPepperoni.setOn(false)
                swPepperoniStatus = false
                ingredientes["Pepperoni"] = nil
            }
            setPizzaIngredientes(ingredientes)
        }
   }
    
    @IBAction func swPavo(value: Bool) {
        if swPavoStatus == true {
            ingredientes["Pavo"] = nil
            setPizzaIngredientes(ingredientes)
        }else {
            if availableSpace() {
                ingredientes["Pavo"] = "Pavo"
            }else {
                swPavo.setOn(false)
                swPavoStatus = false
                ingredientes["Pavo"] = nil
            }
            setPizzaIngredientes(ingredientes)
        }
    }
    
    @IBAction func swSalchicha(value: Bool) {
        if swSalchichaStatus == true {
            ingredientes["Salchicha"] = nil
            setPizzaIngredientes(ingredientes)
        }else {
            if availableSpace() {
                ingredientes["Salchicha"] = "Salchicha"
            }else {
                swSalchicha.setOn(false)
                swSalchichaStatus = false
                ingredientes["Salchicha"] = nil
            }
            setPizzaIngredientes(ingredientes)
        }
    }
    
    @IBAction func swAceituna(value: Bool) {
        if swAceitunaStatus == true {
            ingredientes["Aceituna"] = nil
            setPizzaIngredientes(ingredientes)
        }else {
            if availableSpace() {
                ingredientes["Aceituna"] = "Aceituna"
            }else {
                swAceituna.setOn(false)
                swAceitunaStatus = false
                ingredientes["Aceituna"] = nil
            }
            setPizzaIngredientes(ingredientes)
        }
    }
    
    @IBAction func swCebolla(value: Bool) {
        if swCebollaStatus == true {
            ingredientes["Cebolla"] = nil
            setPizzaIngredientes(ingredientes)
        }else {
            if availableSpace() {
                ingredientes["Cebolla"] = "Cebolla"
            }else {
                swCebolla.setOn(false)
                swCebollaStatus = false
                ingredientes["Cebolla"] = nil
            }
            setPizzaIngredientes(ingredientes)
        }
   }
 
    @IBAction func swPimiento(value: Bool) {
        if swPimientoStatus == true {
            ingredientes["Pimiento"] = nil
            setPizzaIngredientes(ingredientes)
        }else {
            if availableSpace() {
                ingredientes["Pimiento"] = "Pimiento"
            }else {
                swPimiento.setOn(false)
                swPimientoStatus = false
                ingredientes["Pimiento"] = nil
            }
            setPizzaIngredientes(ingredientes)
        }
   }
    
    @IBAction func swPina(value: Bool) {
        if swPinaStatus == true {
            ingredientes["Piña"] = nil
            setPizzaIngredientes(ingredientes)
        }else {
            if availableSpace() {
                ingredientes["Piña"] = "Piña"
            }else {
                swPina.setOn(false)
                swPinaStatus = false
                ingredientes["Piña"] = nil
            }
            setPizzaIngredientes(ingredientes)
        }
    }
    
    @IBAction func swAnchoa(value: Bool) {
        if swAnchoaStatus == true {
            ingredientes["Anchoa"] = nil
            setPizzaIngredientes(ingredientes)
        }else {
            if availableSpace() {
                ingredientes["Anchoa"] = "Anchoa"
            }else {
                swAnchoa.setOn(false)
                swAnchoaStatus = false
                ingredientes["Anchoa"] = nil
            }
            setPizzaIngredientes(ingredientes)
        }
   }
    
    @IBAction func swAlcaparras(value: Bool) {
        if swAlcaparraStatus == true {
            ingredientes["Alcaparras"] = nil
            setPizzaIngredientes(ingredientes)
        }else {
            if availableSpace() {
                ingredientes["Alcaparras"] = "Alcaparras"
            }else {
                swAlcaparras.setOn(false)
                swAlcaparraStatus = false
                ingredientes["Alcaparras"] = nil
            }
            setPizzaIngredientes(ingredientes)
        }
    }
    
    func setPizzaIngredientes(ingredientse: [String: String]) {
        //Stept: 3
        if delegate != nil {
            delegate!.setPizzaIngredientes(ingredientes)
        }
    }

}
