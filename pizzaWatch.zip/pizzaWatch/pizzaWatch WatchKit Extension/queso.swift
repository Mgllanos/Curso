//
//  queso.swift
//  pizzaWatch
//
//  Created by Marta González-Llanos on 9/6/16.
//  Copyright © 2016 Marta González-Llanos. All rights reserved.
//

import WatchKit
import Foundation

protocol quesoPizzaDelegate {
    func setPizzaQueso(queso:String)
}

class queso: WKInterfaceController {

    @IBOutlet var swMozzarella: WKInterfaceSwitch!
    @IBOutlet var swCheddar: WKInterfaceSwitch!
    @IBOutlet var swParmesano: WKInterfaceSwitch!
    @IBOutlet var swSinQueso: WKInterfaceSwitch!

    var delegate: quesoPizzaDelegate? = nil
    var pizzaQuesoTmp:  Pizza?
    

    
    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
        
        // Configure interface objects here.
        
        let myContext = context as! Pizza
        delegate = myContext.delegate as? quesoPizzaDelegate
        pizzaQuesoTmp = myContext
        setQueso()

    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    func setQueso() {
        if let cheeseOld = pizzaQuesoTmp?.claseQueso {
            switch cheeseOld {
            case "Mozzarella":
                swMozzarella.setOn(true)
            case "Cheddar":
                swCheddar.setOn(true)
            case "Parmesano":
                swParmesano.setOn(true)
            case "Sin Queso":
                swSinQueso.setOn(true)
            default:
                swSinQueso.setOn(false)
            }
        }
    }
    
    @IBAction func swMozzarella(value: Bool) {
        swCheddar.setOn(false)
        swParmesano.setOn(false)
        swSinQueso.setOn(false)
        setPizzaQueso("Mozzarella");    }
    
    @IBAction func swCheddar(value: Bool) {
        swMozzarella.setOn(false)
        swParmesano.setOn(false)
        swSinQueso.setOn(false)
        setPizzaQueso("Cheddar");
    }
    
    @IBAction func swParmesano(value: Bool) {
        swSinQueso.setOn(false)
        swCheddar.setOn(false)
        swMozzarella.setOn(false)
        setPizzaQueso("Parmesano");
   }
    
    @IBAction func swSinQueso(value: Bool) {
        swMozzarella.setOn(false)
        swCheddar.setOn(false)
        swParmesano.setOn(false)
        setPizzaQueso("Sin queso");   }
    
    func setPizzaQueso (queso: String) {
        //Stept: 3
        if delegate != nil {
            delegate!.setPizzaQueso(queso)
            //            self.navigationController?.popViewControllerAnimated(true)
        }
    }

}
