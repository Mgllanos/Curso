//: Playground - noun: a place where people can play

import UIKit

enum Velocidades: Int {

    case Apagado = 0, VelocidadBaja = 20, VelocidadMedia = 50, VelocidadAlta = 120

    init( velocidadInicial : Velocidades ) {
    
    self  = velocidadInicial
    
    }
}

class Auto {
    
    var velocidad : Velocidades
    var estadoNumerico : Int
    
    
    init (){
        self.velocidad = .Apagado
        estadoNumerico = self.velocidad.rawValue
    }
    func cambioDeVelocidad( ) -> ( actual : Int, velocidadEnCadena: String) {
        let leyenda : String
        estadoNumerico = self.velocidad.rawValue
        
        switch self.velocidad{
        case .Apagado:
            self.velocidad = .VelocidadBaja
            leyenda = "Apagado"
        case .VelocidadBaja:
            self.velocidad = .VelocidadMedia
            leyenda = "Velocidad Baja"
        case .VelocidadMedia:
            self.velocidad = .VelocidadAlta
            leyenda = "Velocidad Media"
        case .VelocidadAlta:
            self.velocidad = .VelocidadMedia
            leyenda = "Velocidad Alta"
}
        return (estadoNumerico, velocidadEnCadena: leyenda)

}

}

var auto = Auto ()
var resultado : (actual : Int, velocidadEnCadena : String)

for i in 1...20 {
    
    resultado = auto.cambioDeVelocidad()
    print (resultado)
}


